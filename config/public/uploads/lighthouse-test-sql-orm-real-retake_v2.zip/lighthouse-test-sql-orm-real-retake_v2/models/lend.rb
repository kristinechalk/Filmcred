class Lend < ActiveRecord::Base
belongs_to :library
belongs_to :book 




  def days
    self.due - self.checkout
  end


  def fees  
    self.library.revenue = ((self.checkin - self.due) * self.library.late_fee)
    self.library.save
  end



end
