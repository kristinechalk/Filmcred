require './spec_helper'

describe Lend do

	subject(:lend) { FactoryGirl.build :lend }

	describe "extended" do

		it "should be false if book is checked out for 2 days or less" do
			lend.extended.should be_false
		end

		it "should be true if book is checked out for more than 2 days" do
			lend.due = 10.days.from_now.to_date
			lend.save

			lend.extended.should be_true
		end
	end

end
